#include <stdio.h>

int error(const char* msg){
    printf("%s",msg);
    return 0;
};