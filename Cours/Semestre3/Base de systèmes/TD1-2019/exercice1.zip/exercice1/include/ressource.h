#ifndef __PERS__H__
#define __PERS__H__ 

// ============================================================================
// ressources globales


 char pers[81];

#endif
