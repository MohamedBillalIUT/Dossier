#ifndef __HELLO__H__
#define __HELLO__H__ 

// ============================================================================
// entete pour les fonctions

  void  hello(void);
  void lire(void);

#endif
