
#include <ressource.h>
#include <hello.h>

int main(void) {
	lire();
	hello();
	return 0;
}



