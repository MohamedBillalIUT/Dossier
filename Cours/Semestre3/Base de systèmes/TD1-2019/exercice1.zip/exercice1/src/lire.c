#include <stdio.h>
#include "../include/ressource.h"

void lire(void) {
	fgets(pers,80,stdin);  //lecture relativement securisee, pour max 80 car., fgets met un \0 aussi
}



