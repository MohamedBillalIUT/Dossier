#include <stdio.h>
#include "../include/ressource.h"

void hello(void) {
	printf("Hello %s\n",pers);
}



