public class HelloWorld {
    public static void main(String[] args) {
        // À COMPLETER

        System.out.println("Salut le monde");
    }
}
